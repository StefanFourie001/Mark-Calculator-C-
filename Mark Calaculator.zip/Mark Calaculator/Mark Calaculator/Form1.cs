﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mark_Calaculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double PMark = double.Parse(txtPMark.Text);
            double WeightP = double.Parse(txtWeightP.Text);
            double EMark = double.Parse(txtEMark.Text);
            double WeightE = double.Parse(txtWeightE.Text);
            double TotalP = 0;
            double TotalE = 0;
            double Module = 0;
            double FinalModule = 0;

            string ModuleName = txtName.Text;

            TotalP = PMark / 100 * WeightP;
            TotalE = EMark / 100 * WeightE;
            Module = TotalP + TotalE;
            FinalModule = Module;

            MessageBox.Show("Your final Mark for " + ModuleName + " is : " + FinalModule.ToString("P"));


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEMark.Clear();
            txtName.Clear();
            txtPMark.Clear();
            txtWeightE.Clear();
            txtWeightP.Clear();
        }
    }
}
